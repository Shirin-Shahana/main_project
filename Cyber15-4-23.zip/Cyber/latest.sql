/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.5.5-10.3.20-MariaDB : Database - cyber_bullying
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`cyber_bullying` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `cyber_bullying`;

/*Table structure for table `bullying` */

DROP TABLE IF EXISTS `bullying`;

CREATE TABLE `bullying` (
  `l_id` int(11) DEFAULT NULL COMMENT 'contains the login id',
  `bull_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'contains the bullying id',
  `bull_word` varchar(100) DEFAULT NULL COMMENT 'contains the bullying word',
  `date` date DEFAULT NULL COMMENT 'contains the date',
  PRIMARY KEY (`bull_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

/*Data for the table `bullying` */

insert  into `bullying`(`l_id`,`bull_id`,`bull_word`,`date`) values (1,1,'shame','2021-05-18'),(1,3,'toxic','2021-05-28'),(1,4,'ugly','2021-05-28'),(1,5,'gross','2021-05-28'),(5,6,'bad','2021-05-28'),(7,7,'vulgure','2021-07-11');

/*Table structure for table `chat` */

DROP TABLE IF EXISTS `chat`;

CREATE TABLE `chat` (
  `chat_id` int(11) DEFAULT NULL,
  `sender_id` int(11) DEFAULT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `meassage` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `out` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `chat` */

/*Table structure for table `comment` */

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `comment` */

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `date_time` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `comments` */

/*Table structure for table `complaint` */

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `complaint` varchar(100) DEFAULT NULL,
  `reply` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`complaint_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `complaint` */

insert  into `complaint`(`complaint_id`,`user_id`,`complaint`,`reply`,`date`) values (2,1,'dsf','pending','2022-06-03 10:33:36');

/*Table structure for table `friends` */

DROP TABLE IF EXISTS `friends`;

CREATE TABLE `friends` (
  `friends_id` int(11) NOT NULL AUTO_INCREMENT,
  `friend_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date_time` varchar(50) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`friends_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `friends` */

insert  into `friends`(`friends_id`,`friend_id`,`user_id`,`date_time`,`status`) values (1,1,2,'2022-06-15 21:40:13','Accept'),(2,2,1,'2023-03-06 09:36:37','pending');

/*Table structure for table `good` */

DROP TABLE IF EXISTS `good`;

CREATE TABLE `good` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `word` varchar(500) NOT NULL,
  `date` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `good` */

insert  into `good`(`id`,`lid`,`word`,`date`) values (2,1,'great','2021-05-28'),(3,1,'beautiful','2021-05-28'),(4,1,'love','2021-05-28'),(5,1,'best','2021-05-28'),(6,1,'sweet','2021-05-28'),(7,1,'romantic','2021-05-28'),(8,1,'lovely','2021-05-28'),(9,1,'brave','2021-05-28'),(11,1,'splendid','2021-05-28'),(12,1,'congrats','2021-07-11');

/*Table structure for table `login` */

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `usertype` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `login` */

insert  into `login`(`login_id`,`username`,`password`,`usertype`) values (1,'admin','admin','admin'),(2,'anna','anna123','user'),(5,'yy','yy','user');

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `post` varchar(100) DEFAULT NULL,
  `path` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `post` */

insert  into `post`(`post_id`,`user_id`,`post`,`path`,`date`,`status`) values (1,1,'dfkgh','static/uploads/70b2e328-cf53-4540-8255-501b7c0e9441abc.jpg','2022-06-15 21:47:10','pending'),(2,2,'very happy','static/uploads/daef58d0-2804-4700-b24d-11b32d001bb9abc.jpg','2022-06-15 22:09:10','pending'),(3,2,'happy','static/uploads/88bae744-a64e-43b4-95ba-17b084e4b5e3abc.jpg','2022-06-16 12:11:20','pending'),(4,1,'hhh','static/uploads/d62b65fa-c2dd-4a45-bce1-a15394ae2882abc.jpg','2023-03-06 09:51:20','pending');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `age` varchar(100) DEFAULT NULL,
  `emnum` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`login_id`,`fname`,`lname`,`place`,`phone`,`email`,`age`,`emnum`) values (1,2,'Anna','Rose','kochi','9898989989','anna@gmail.com',NULL,NULL),(2,5,'4ret','ttt','hehe@yeeme.rud','222559638825','ddff',NULL,NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
